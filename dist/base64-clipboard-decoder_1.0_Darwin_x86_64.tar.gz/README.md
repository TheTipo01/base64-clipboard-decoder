# base64-clipboard-decoder
Little program for decoding and opening an url encoded in Base64
